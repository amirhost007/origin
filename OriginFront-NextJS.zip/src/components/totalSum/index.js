const totalSum = (...args) => args.reduce((a, b) => a + b);
export default totalSum;
